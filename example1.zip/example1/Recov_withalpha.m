%% This code is used to measure the reconstruction error with different value.
% pleaure run the example1 first to get the estimated IF and chirprate.
  j = -10:10;
  alpha0 = (2.^(0.5*j))' .* alpha;  
   for  kk=1:21
      alphak=alpha0(kk,:);
      alphakk=alphak(p);
     
  if p==1
[tfc1] =WLCT_aW_dyadic(x, Hz, alphakk,delta_a,a0);
elseif p==5
[tfc1]  =WLCT_theta_dyadic(x, Hz, alphakk,delta_a,a0);
elseif p==2
[tfc1] =WLCT_cW1(x, Hz, alphakk,chrrange);
elseif p==6
[tfc1]=WLCT_ThetaW1(x, Hz, alphakk,chrrange);
else
    error('Invalid value of p');
end
[recov,cn] = recov_SSO_group(if1, if2, chirp1, chirp2, IFs,CRs, tfc1,alphak, p);
[errorx1,errorx2] = MSE_recov(x1,x2,recov);
disp([errorx1,errorx2])
 error=errorx1+errorx2;
  load('Recov.mat');    %the storage of the condition number
  Recov(p,kk,:)=[alphakk,error];
  save('Recov.mat', 'Recov');
   end









plot(j,Recov(1,:,2), 'color', 'r', 'LineWidth', 2);  
hold on;
plot(j,Recov(2,:,2), 'color', 'k', 'LineWidth', 2);  
plot(j,Recov(5,:,2), 'color', 'g', 'LineWidth', 2);  
plot(j, Recov(6,:,2), 'color', 'm', 'LineWidth', 2);  
legend('n=1', 'n=2', 'n=5', 'n=6', 'FontSize', 20);
xlabel('Scale parameter j', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Reconstruction error', 'FontSize', 20,'FontName', 'Times New Roman');  
set(gca, 'FontSize', 20);
axis xy;



