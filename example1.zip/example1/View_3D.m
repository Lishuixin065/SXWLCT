
if p==1 ||p==5
QN = 5 ;t_idx = 1:length(t);
D = tfc1(:,:,t_idx);
thresh = quantile(abs(D(:)),0.9995);
D(abs(D) < thresh * (10-QN+1)/10) = thresh * (10-QN)/10 ;
 
for jj = 1: QN
    idx = find(abs(D) <= thresh * (10-jj+1)/10 & abs(D) > thresh * (10-jj)/10 );
    [I1,I2,I3] = ind2sub(size(D),idx);
    scatter3(t(I3), tfrtic(I2) , 1./tcrtic(I1) , 5,  [1 1 1]*(jj-1)/8,  'filled'); 
    hold on
end
view(30,30)
xlabel('time (s)');
ylabel('frequency (Hz)');
zlabel('1./chirp rate');

colormap(1-gray)
title('3D Plot of CT with g_0'); 










elseif p==2||p==6
QN = 5 ;t_idx = 1:length(t);
D = tf_sc(:,:,t_idx);
thresh = quantile(abs(D(:)),0.999);
D(abs(D) < thresh * (10-QN+1)/10) = thresh * (10-QN)/10 ;
 
for jj = 1: QN
    idx = find(abs(D) <= thresh * (10-jj+1)/10 & abs(D) > thresh * (10-jj)/10 );
    [I1,I2,I3] = ind2sub(size(D),idx);
    scatter3(t(I3), tfrtic(I2) , -tcrtic(I1) , 5,  [1 1 1]*(jj-1)/8,  'filled'); 
    hold on
end
view(30,30)
xlabel('time (s)');
ylabel('frequency (Hz)');
zlabel('-chirp rate');
colormap(1-gray)
title('3D Plot of CT with g_0'); 


end