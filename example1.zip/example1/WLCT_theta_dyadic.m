function [tfc] = WLCT_theta_dyadic(x, Hz, alpha,delta_a,a0)
% Inputs:
%   x - Input signal (column vector)
%   Hz - Sampling frequency
%   alpha - Parameter for the Gaussian window
%   delta_a - Step size for chirp rate discretization
%   a0 -  scale factor

% Outputs:
%   tfc - Synchrosqueezed transform matrix


[xrow,xcol] = size(x) ;
	%% check input signals
if (xcol~=1)
    error('x must have only one column');

end


Lh=xrow;N=xrow;


% for tfrsq

ht = -Lh:Lh ;
time=ht/Hz;

t = 1:length(x) ;



pcrate=zeros(1,round(0.5*N));

for j=1:round(0.5*N)
pcrate(j)=2^((j)*delta_a).*a0;
end
ncrate =(-1)* fliplr(pcrate); 
crate=[ncrate,0,pcrate];





tfrtic =Hz*(0:round(xrow/2)-1)/xrow ;
tcrtic = 1./crate;% discretization of chirp rate

tLen = length(t(1:length(x))) ;% number of bins of time
fLen =length(tfrtic) ; % number of bins of frequency
cLen = length(crate); % number of bins of chirp rate


	%% run STFT and reassignment rule
tfc =zeros(cLen, fLen, tLen); % synchrosqueezed chirplet transform
lambda=zeros(cLen, fLen, tLen);omega=zeros(cLen, fLen, tLen);
%t = 1:length(x) ;

fprintf(['Chirp-rate total: ',num2str(cLen), '; now:     ']) ;


for cidx = 1:cLen
    fprintf('\b\b\b\b') ;	

    tmp = sprintf('%4d',cidx) ; 

    fprintf(tmp) ;

    chirp = crate(cidx);
    for tidx = 1:tLen      
        % ti is the current time
        ti = t(tidx);
        % tau is the relevant index associated with ti
        tau = -min([round(N/2)-1,Lh,ti-1]):min([round(N/2)-1,Lh,xrow-ti]);
        % indices is the absolute index in the "evaluation window"
        indices= rem(N+tau,N)+1;      
         tf0 = zeros(N, 1) ; 
      L=sqrt(-1i*(1-1i*chirp))./sqrt(alpha-1i*chirp);
     
      tf0(indices) =L* x(ti+tau).*conj(exp((-pi*alpha*time(Lh+1+tau).^2'*(1+chirp^2))/(alpha^2+chirp^2)).* ...
           exp((pi*1i*chirp.*(time(Lh+1+tau)').^2*(1-alpha^2))/(alpha^2+chirp^2))); % for CT with window g
  
        
        tf0 = fft(tf0)/Hz ; tf0 = tf0(1:N/2) ;
      
        tfc(cidx, :, tidx) = tf0(1:N/2) ;
      
       
    end
  
end

fprintf('\n') ;

end



