clear;
Hz = 128;
L = 4 ; % time duration in second
deltat=1/Hz;
t = (1/Hz:1/Hz:L)' ;
x1 =exp(2*pi*1i*(-4*t.^2+50*t)); % first component
der_x1=-8*t+50;
dder_x1=-8*ones(length(t),1);
x2 = exp(2*pi*1i*(6*t.^2 + 10*t)); % second component
der_x2=12*t+10;
dder_x2=12*ones(length(t),1);

figure
pdph1=plot(t,der_x1,'r-','linewidth',2);
hold on
pdph2=plot(t,der_x2,'b-','linewidth',2);
legend([pdph1,pdph2],'\phi_1^{\prime}(t)','\phi_2^{\prime}(t)','Location','northwest');
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 



figure
pddph1=plot(t,dder_x1,'r-','linewidth',2);
hold on
pddph2=plot(t,dder_x2,'b-','linewidth',2);
legend([pddph1,pddph2],'\phi_1^{\prime\prime}(t)','\phi_2^{\prime\prime}(t)');
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 


% different windows
x=(x1 + x2);



alpha1 = 0.05;alpha2 =6.2; alpha5 = 0.061; alpha6 =23;
alpha=[alpha1,alpha2, 0,0,alpha5,alpha6];

delta_a=1/32;chrrange=30;a0=1/Hz;

% the alpha vale are obtained by renyi entroy (l=2.5)
%alpha1=0.048-0.050;
%alpha5=0.061-0.064;
%alpha2=6.2-6.6;
%alpha6=gs=23-23.5 ;

%% please chose one modes to run
p=6;
%p - Type of SWLCT 
profile on -memory; profile off;

if p==1
[tfc1, lambda1,omega1,tfrtic, tcrtic] =SWLCT1_dyadic1(x, Hz, alpha1,delta_a,a0);
elseif p==5
[tfc1, lambda1,omega1,tfrtic, tcrtic]  =SWLCT5_dyadic1(x, Hz, alpha5,delta_a,a0);
elseif p==2
[tfc1, lambda1,omega1,tfrtic, tcrtic] =SWLCT2_1(x, Hz, alpha2,chrrange);
elseif p==6
[tfc1, lambda1,omega1,tfrtic, tcrtic]=SWLCT6_1(x, Hz, alpha6,chrrange);
else
    error('Invalid value of p');
end
profile viewer;  

% p=1 time   62.02s  1.0039G
% p=2 time   56.67s  1.0039G
% p=5 time   66.22s  1.0039G
% p=6 time   64.08s  1.0039G



%% Synchrosqueezed
freq_resol=1/12;chr_resol=1/25;%Reset resolution
[tf_sc]=Xray_transform(tfc1,tfrtic,tcrtic,1,t,2/Hz);

[tfrsq1,newtfrtic,newtcrtic] = Msqueeze1(x,tfc1, lambda1, omega1,chrrange,freq_resol,chr_resol, deltat);
%[tfrsq1,newtfrtic,newtcrtic] = Msqueeze1(x,tf_sc, lambda1, omega1,chrrange,freq_resol,chr_resol, deltat);



[NIFs,NCRs]=ridge_3D(tfrsq1,2,5,5,0.00001,0.00001,10);% 3D ridges exctors
% Make the curve smoother
 for i=1:length(t)
       % if1 = smooth(medfilt1(newtfrtic(NIFs(:,1))));
       % if2 = smooth(medfilt1(newtfrtic(NIFs(:,2))));
       % chirp1=smooth(medfilt1(newtcrtic(NCRs(:,1))));
       % chirp2=smooth(medfilt1(newtcrtic(NCRs(:,2))));
       % 
       if1 =smooth(newtfrtic(NIFs(:,1)));
       if2 =smooth(newtfrtic(NIFs(:,2)));
       chirp1=smooth(newtcrtic(NCRs(:,1)));
       chirp2=smooth(newtcrtic(NCRs(:,2)));       
 end








%%  plot ridge
figure;
h1 = plot(t, if1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated IFs'); 
hold on;
plot(t, if2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
h2 = plot(t, der_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, der_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
legend([h1, h2], 'FontName', 'Times New Roman', 'FontSize', 20,'Location', 'northwest');
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency(Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([10 66]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);




figure;
h3 = plot(t, chirp1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated CRs'); 
hold on;
plot(t, chirp2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
h4 = plot(t, dder_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, dder_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
legend([h3, h4], 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Chirprate (Hz/s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([-16 28]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);




%% time-frequency projection
tfproj1 = zeros(size(tfrsq1,2),size(tfrsq1,3));
for i = 1:size(tfproj1,1)
    for j = 1:size(tfproj1,2)
        tfproj1(i,j) = sum(abs((tfrsq1(:,i,j)).^(1)));
    end
end
figure
imageSQ(t, newtfrtic, tfproj1) 
shading interp;
axis xy; 
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency (Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
title('Time-Frequency projection');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);



%% recov signal 
t_idx = 1:length(t);
t_show = t(t_idx);



IFs=zeros(size(NIFs));CRs=zeros(size(NCRs));
for j=1:length(t)
    diff1=abs(tfrtic-if1(j)); diff2=abs(tfrtic-if2(j));       
    [minValue1, minIndex1] = min(diff1); [minValue2, minIndex2] = min(diff2);
    IFs(j,1)=minIndex1; IFs(j,2)=minIndex2;
    diff3=abs(tcrtic-chirp1(j)); diff4=abs(tcrtic-chirp2(j));     
    [minValue3, minIndex3] = min(diff3); [minValue4, minIndex4] = min(diff4);
    CRs(j,1)=minIndex3; CRs(j,2)=minIndex4;
end



[recov,cn] = recov_SSO_group(if1, if2, chirp1, chirp2, IFs,CRs, tfc1,alpha, p);
load('Condnum_data.mat');    %the storage of the condition number
Condnum(:,p)=cn;
save('Condnum_data.mat', 'Condnum');
plot(t,cn)




if sum(abs(real(x1-recov(:,1))))<sum(abs(real(x2-recov(:,1))))
figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);


subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

else

figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);

%title('error of x1 between real-signal and ridge-IF-CR reconstruction signal');
subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

end
[MSEIFx1, MSEIFx2, MSECRx1, MSECRx2] = MSE_ridge(if1, if2, chirp1, chirp2, der_x1, dder_x1, der_x2, dder_x2);
disp([MSEIFx1, MSEIFx2, MSECRx1, MSECRx2])
[errorx1,errorx2] = MSE_recov(x1,x2,recov);
disp([errorx1,errorx2])


% p=1   0.0124    0.0111    0.0584    0.0630   0.0243    0.0135
% p=5   0.0124    0.0128    0.1008    0.0996   0.0213    0.0127
% p=2   0.0308    0.0341    0.3252    0.3398   0.0180    0.0188
% p=6   0.0117    0.0109    0.0449    0.0174   0.0269    0.0134


%% plot condition numbers


% plot(t, Condnum(:,1), 'color', 'r', 'LineWidth', 2);  
% hold on;
% plot(t, Condnum(:,2), 'color', 'k', 'LineWidth', 2);  
% plot(t, Condnum(:,5), 'color', 'g', 'LineWidth', 2);  
% plot(t, Condnum(:,6), 'color', 'm', 'LineWidth', 2);  
% legend('n=1', 'n=2', 'n=5', 'n=6', 'FontSize', 20);
% xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
% ylabel('Condition Number', 'FontSize', 20,'FontName', 'Times New Roman');  
% set(gca, 'FontSize', 20);
% axis xy;
% hold off;
% 



%% plot with a small perturbations
% %%  plot ridge
% snr=15;
% if11=awgn(if1, snr);
% if22=awgn(if2, snr);
% chirp11 = awgn(chirp1, snr);
% chirp22=awgn(chirp2,snr);
% 
% 
% figure;
% h1 = plot(t, if11, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated IFs'); 
% hold on;
% plot(t, if22, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
% h2 = plot(t, der_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
% plot(t, der_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
% legend([h1, h2], 'FontName', 'Times New Roman', 'FontSize', 20,'Location', 'northwest');
% xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
% ylabel('Frequency(Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
% ylim([10 66]);
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% 
% 
% 
% 
% figure;
% h3 = plot(t, chirp11, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated CRs'); 
% hold on;
% plot(t, chirp22, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
% h4 = plot(t, dder_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
% plot(t, dder_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
% legend([h3, h4], 'FontName', 'Times New Roman', 'FontSize', 20);
% xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
% ylabel('Chirprate (Hz/s)', 'FontSize', 20, 'FontName', 'Times New Roman');
% ylim([-16 28]);
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% 
% 
% 
% 
% %% recov signal 
% t_idx = 1:length(t);
% t_show = t(t_idx);
% 
% 
% 
% IFs=zeros(size(NIFs));CRs=zeros(size(NCRs));
% for j=1:length(t)
%     diff1=abs(tfrtic-if11(j)); diff2=abs(tfrtic-if22(j));       
%     [minValue1, minIndex1] = min(diff1); [minValue2, minIndex2] = min(diff2);
%     IFs(j,1)=minIndex1; IFs(j,2)=minIndex2;
%     diff3=abs(tcrtic-chirp11(j)); diff4=abs(tcrtic-chirp22(j));     
%     [minValue3, minIndex3] = min(diff3); [minValue4, minIndex4] = min(diff4);
%     CRs(j,1)=minIndex3; CRs(j,2)=minIndex4;
% end
% 
% 
% 
% 
% 
% 
% if sum(abs(real(x1-recov(:,1))))<sum(abs(real(x2-recov(:,1))))
% figure
% subplot(2, 1, 1);
% plot(t_show, real(x1(t_idx))-real(recov(t_idx,1)), 'k');
% ylim([-1.5 1.5]);
% legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% xlabel('Time (s)','FontSize',20);
% 
% 
% subplot(2, 1, 2);
% plot(t_show, real(x2(t_idx))-real(recov(t_idx,2)), 'k');
% ylim([-1.5 1.5]);
% legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% xlabel('Time (s)','FontSize',20);
% %title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');
% 
% else
% 
% figure
% subplot(2, 1, 1);
% plot(t_show, real(x1(t_idx))-real(recov(t_idx,2)), 'k');
% ylim([-1.5 1.5]);
% legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% xlabel('Time (s)','FontSize',20);
% 
% %title('error of x1 between real-signal and ridge-IF-CR reconstruction signal');
% subplot(2, 1, 2);
% plot(t_show, real(x2(t_idx))-real(recov(t_idx,1)), 'k');
% ylim([-1.5 1.5]);
% legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
% set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
% xlabel('Time (s)','FontSize',20);
% %title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');
% 
% end
% [MSEIFx1, MSEIFx2, MSECRx1, MSECRx2] = MSE_ridge(if1, if2, chirp1, chirp2, der_x1, dder_x1, der_x2, dder_x2);
% disp([MSEIFx1, MSEIFx2, MSECRx1, MSECRx2])
% [errorx1,errorx2] = MSE_recov(x1,x2,recov);
% disp([errorx1,errorx2])
% 
% 
% 
% 
