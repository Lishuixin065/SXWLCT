function [tfc, tfrtic, tcrtic] = WLCT_AW_dyadic(x, Hz, alpha,delta_a)

[xrow,xcol] = size(x) ;
	%% check input signals
if (xcol~=1)
    error('x must have only one column');

end


Lh=xrow;N=xrow;


% for tfrsq

ht = -Lh:Lh ;
time=ht/Hz;

t = 1:length(x) ;

pcrate=zeros(1,round(0.5*N));

for j=1:round(0.5*N)
pcrate(j)=2^((j)*delta_a)/Hz;
end
ncrate =(-1)* fliplr(pcrate); % 先反转数组
crate=[ncrate,0,pcrate];


tfrtic =Hz*(0:round(xrow/2)-1)/xrow ;
tcrtic =1./ crate;% discretization of chirp rate

tLen = length(t(1:length(x))) ;% number of bins of time
fLen =length(tfrtic) ; % number of bins of frequency
cLen = length(crate); % number of bins of chirp rate


	%% run STFT and reassignment rule
tfc =zeros(cLen, fLen, tLen); % synchrosqueezed chirplet transform
%t = 1:length(x) ;

%1.0e-6=1.0 * 10^(-6)
fprintf(['Chirp-rate total: ',num2str(cLen), '; now:     ']) ;
%字符串 "; now:     " 的作用是在命令行输出中预留一个位置，用于之后显示当前的进度或状态。
% 这里的 "now:" 是一个标签，紧接着的空格是为后面的数字预留的空间，这样当您使用 \b（退格符）
% 回退并重新打印当前进度时，可以准确地覆盖这些空格，而不会破坏命令行中已经存在的其他文本。

for cidx = 1:cLen
    fprintf('\b\b\b\b') ;	
%在每次循环迭代中，这行代码使用四个退格符 \b 来将命令窗口中的光标向左移动四个位置
% 这样做是为了在不换行的情况下，覆盖上一次迭代中打印的当前扫频序号。
    tmp = sprintf('%4d',cidx) ; 
%sprintf 函数将当前的 cidx 转换为一个格式化的字符串 tmp，其中 '%4d' 指定了输出为
% 至少 4 个字符宽的十进制整数。如果 cidx 是一位数，前面会用空格填充以保持格式的一致性。
    fprintf(tmp) ;
%与之前的now联合使用，这样当前的 cidx 值就会显示在 "now:" 后面。
    chirp = crate(cidx);
    for tidx = 1:tLen      
        % ti is the current time
        ti = t(tidx);
        % tau is the relevant index associated with ti
        tau = -min([round(N/2)-1,Lh,ti-1]):min([round(N/2)-1,Lh,xrow-ti]);
        % indices is the absolute index in the "evaluation window"
        indices= rem(N+tau,N)+1;      
        tf0 = zeros(N, 1) ; 
      L=1./sqrt(alpha*1i+chirp);

     % tf0(indices) =L* x(ti+tau).*(time(Lh+1+tau)').^2.*conj(exp((-pi*alpha*time(Lh+1+tau).^2')/(alpha^2+chirp^2)).* ...
     %  exp((pi*1i*chirp.*(time(Lh+1+tau)').^2)/(alpha^2+chirp^2))); % for CT with window g
       tf0(indices) =L* x(ti+tau).*conj(exp((-pi*alpha*time(Lh+1+tau).^2')/(alpha^2+chirp^2)).* ...
           exp((pi*1i*chirp.*(time(Lh+1+tau)').^2)/(alpha^2+chirp^2))); % for CT with window g
        
        
        tf0 = fft(tf0) ; tf0 = tf0(1:N/2) ;       

        tfc(cidx, :, tidx) = tf0(1:N/2) ;
    
           
       
    end
    %tidx循环结束
end
%cidx循环结束
fprintf('\n') ;
%控制换行用的
end
