
%%%%%%%%%%%%%%%% Example1 %%%%%%%%%%%%%%
clear;
Hz = 128;
L = 4 ; % time duration in second
deltat=1/Hz;
t = (1/Hz:1/Hz:L)' ;
x1 =exp(2*pi*1i*(-4*t.^2+50*t)); % first component
der_x1=-8*t+50;
dder_x1=-8*ones(length(t),1);
x2 = exp(2*pi*1i*(6*t.^2 + 10*t)); % second component
der_x2=12*t+10;
dder_x2=12*ones(length(t),1);


x = x1 + x2; % input signal
l=2.5;
delta=1/32;chrrange=30;

%%
% gs_del=0.001; gs=0.03:gs_del:0.06;
% [opt_gs1,entro1]=find_sigma_WLCT_AW_dyadic(x,Hz,l,delta,gs);
% %example1 delta_a=1/32; l=2.5,gs=0.048-0.050,entro=15.9042; gs_del=0.001;gs=0.001:gs_del:0.2;

%%
% gs_del=0.001; gs=0.04:gs_del:0.07;
% [opt_gs2,entro2]=find_sigma_WLCT_thetaW_dyadic(x,Hz,l,delta,gs);
% %%example1 delta_a=1/32; l=2.5,gs=0.061-0.064,entro=15.9496;gs_del=0.001;gs=0.001:gs_del:0.2;






%%
% gs_del=0.1; gs=5:gs_del:7;
% [opt_gs3,entro3]=find_sigma_WLCT_CW(x,Hz,l,chrrange,gs);

%%example1 ; l=2.5,gs=6.2-6.6,chrrange=30; entro=15.9006; gs_del=0.1;gs=1:gs_del:5;

%%
gs_del=0.5;gs=20:gs_del:30; 
[opt_gs4,entro4]=find_sigma_WLCT_ThetaW(x,Hz,l,chrrange,gs);

%example1 ; l=2.5,gs=23-23.5,chrrange=30;entro=15.7759; gs_del=0.5;gs=1:gs_del:100;
