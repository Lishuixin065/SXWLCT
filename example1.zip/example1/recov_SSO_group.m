function [recov,cn] = recov_SSO_group(if1, if2, chirp1, chirp2, IFs,CRs,tfc1, alpha, p)

% Inputs:
%   if1 - Instantaneous frequency of the first component
%   if2 - Instantaneous frequency of the second component
%   chirp1 - Chirp rate of the first component
%   chirp2 - Chirp rate of the second component
%   IFs - Index of estimated instantaneous frequencies
%   CRs - Index of estimated chirp rates
%   tfc1 - Time-frequency-chirprate representation of the signal
%   alpha -  parameter for the Gaussian window
%   p - Type of window function to use (1: AW, 2: \theta W, 3: CW, 4: \Theta W)

% Outputs:
%   recov - Recovered signal components (2-column matrix)



    recov = zeros(length(if1), 2); 
    scale = alpha(p);
    cn=zeros(length(if1), 1);

if p==1    
   for char = 1:length(if1)
    tmp = zeros(2,2);
    tmp(1,1) = Gaussian_ag(1./chirp1(char),chirp1(char),0,scale);
    tmp(1,2) = Gaussian_ag(1./chirp1(char),chirp2(char),if2(char)-if1(char),scale);   
    tmp(2,1) =Gaussian_ag(1./chirp2(char),chirp1(char),if1(char)-if2(char),scale);
    tmp(2,2) = Gaussian_ag(1./chirp2(char),chirp2(char),0,scale) ;
     cn(char)=cond(tmp);
    xtmp = [tfc1(CRs(char,1),IFs(char,1),char); tfc1(CRs(char,2),IFs(char,2),char)];    
    recov(char,:) = pinv(tmp + 1*eps) * xtmp;
   
   end

elseif p==5

   for char = 1:length(if1) 
       
   tmp = zeros(2,2);
    tmp(1,1) = Gaussian_theta_g(1./chirp1(char),chirp1(char),0,scale);
    tmp(1,2) = Gaussian_theta_g(1./chirp1(char),chirp2(char),if2(char)-if1(char),scale);   
    tmp(2,1) =Gaussian_theta_g(1./chirp2(char),chirp1(char),if1(char)-if2(char),scale);
    tmp(2,2) = Gaussian_theta_g(1./chirp2(char),chirp2(char),0,scale) ;
      cn(char)=cond(tmp);
    xtmp = [tfc1(CRs(char,1),IFs(char,1),char); tfc1(CRs(char,2),IFs(char,2),char)];    
    recov(char,:) = pinv(tmp + 1*eps) * xtmp;
  
    end
elseif p==2
   
   for char = 1:length(if1)
        
    tmp = zeros(2,2);
    tmp(1,1) = Gaussian_cg(0,0,scale);
    tmp(1,2) = Gaussian_cg(if1(char)-if2(char),chirp2(char) - chirp1(char),scale);   
    tmp(2,1) =Gaussian_cg(if2(char)-if1(char),chirp1(char) - chirp2(char),scale);
    tmp(2,2) =Gaussian_cg(0,0,scale) ;
     cn(char)=cond(tmp);
    xtmp = [tfc1(CRs(char,1),IFs(char,1),char); tfc1(CRs(char,2),IFs(char,2),char)];  
    recov(char,:) = pinv(tmp + 1*eps) * xtmp;
   
   end

elseif p==6
    for char = 1:length(if1)
      
    tmp = zeros(2,2);
    tmp(1,1) = Gaussian_Theta_g(-chirp1(char),chirp1(char),0,scale);
    tmp(1,2) = Gaussian_Theta_g(-chirp1(char),chirp2(char),if2(char)-if1(char),scale);   
    tmp(2,1) = Gaussian_Theta_g(-chirp2(char),chirp1(char),if1(char)-if2(char),scale);
    tmp(2,2) = Gaussian_Theta_g(-chirp2(char),chirp2(char),0,scale) ;
   
    cn(char)=cond(tmp);
    xtmp = [tfc1(CRs(char,1),IFs(char,1),char); tfc1(CRs(char,2),IFs(char,2),char)]; 
    recov(char,:) = pinv(tmp + 1*eps) * xtmp; 
     
    end

 else
    error('Invalid value of p');
 end
  


end





%% AW
function [CTg] = Gaussian_ag(a,b, et, alpha) 
   L=1./(alpha-a*1i)-1i*b;
   CTg = 1 ./ sqrt(alpha*1i+a).*L^(-0.5)*exp(-pi*et^2./L);   
end

%% \theta W
function [CTg] = Gaussian_theta_g(a,b, et, alpha) 
    G=sqrt(-1i*(1-1i*a))./sqrt(alpha-1i*a);
   L=(alpha*(1+a.^2)+1i*(1-alpha^2)*a)./(alpha^2+a^2)-1i*b;
   CTg = G.*L^(-0.5)*exp(-pi*et^2./L);   
end

%% CW
function [CTg] = Gaussian_cg(et, ch, alpha)   
    CTg = 1 ./ sqrt(alpha-1i*ch ) .* exp((-pi*et^2.*(alpha+1i*ch)./(alpha^2+ch.^2)));   
end

%% Theta W
function [CTg] = Gaussian_Theta_g(a,b, et, alpha) 
    G=sqrt(-1i*(1-1i*a))./sqrt(alpha-1i*a);
   L=(alpha*(1+a.^2)+1i*(1-alpha^2)*a)./(alpha^2+a^2)-1i*b;
   CTg = G.*L^(-0.5)*exp(-pi*et^2./L);   
end
