
function [errorx1,errorx2] = MSE_recov(x1,x2,recov)
% MSE_recov Calculates the mean square error of signal recovery for two signals.
% Input parameters:
% x1 : Original signal 1
% x2 : Original signal 2
% reco : Recovered signal (matrix with two columns, one for each original signal)
% 
% Output parameters:
% errorx1 : Mean square error of the recovery for signal 1
% errorx2 : Mean square error of the recovery for signal 2



len=length(x1);
tt=round(len./16):round(15*len./16);ttlen=length(tt);


if sum(real(x1(tt)-recov(tt,1)).^2)<sum(real(x2(tt)-recov(tt,1)).^2)
  
  errorx1=sqrt(1/(ttlen)*sum(real(x1(tt)-recov(tt,1)).^2));
  errorx2=sqrt(1/(ttlen)*sum(real(x2(tt)-recov(tt,2)).^2));
 
else
  errorx1=sqrt(1/(ttlen)*sum(real(x1(tt)-recov(tt,2)).^2));
  errorx2=sqrt(1/(ttlen)*sum(real(x2(tt)-recov(tt,1)).^2));

end





