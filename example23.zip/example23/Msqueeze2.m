
%% Algorithm for multiple compressions
function [tfrsq2,newtfrtic,newtcrtic] = Msqueeze2(x, tfrsq1, lambda, omega,chr_range,freq_resol,chr_resol, del_t)
% Inputs:
%   x - Input signal (column vector)
%   tfrsq1 - Initial time-frequency chirparate representation (3D matrix)
%   lambda - Matrix of chirp rates (3D matrix)
%   omega - Matrix of instantaneous frequencies (3D matrix)
%   chr_range - Range of chirp rates to consider
%   freq_resol -New Frequency resolution
%   chr_resol - New Chirp rate resolution
%   del_t - Time step for iterations

% Outputs:
%   tfrsq2 - Synchrosqueezed time-frequency representation (3D matrix)
%   newtfrtic - New frequency bins
%   newtcrtic - New chirp rate bins



[N1,N2,N3]=size(tfrsq1); 
MM=ceil(1/(2*del_t*freq_resol)); 
newtfrtic=(1:MM)*freq_resol; 
del_cr=chr_resol;
newtcrtic=0:del_cr:chr_range; %size(chr_dis)
MMc=length(newtcrtic); 
 tfrsq2=zeros(MMc,MM,N3); 
Threshold=0.0001* mean(abs(x).^2);
fprintf(['Total time iterations: ', num2str(N3), '; Current:     ']);



    for tidx = 1 : N3
        fprintf('\b\b\b\b');  % Backspace to update the progress
        tmp = sprintf('%4d', tidx);
        fprintf(tmp);  % Print the current iteration index

        lambda1 = squeeze(lambda(:, :, tidx));
        omega1 = squeeze(omega(:,:,tidx));
        tf0 = squeeze(tfrsq1(:,:,tidx));
        lambda2=round(lambda1./chr_resol)+1;
        omega2=round(omega1./freq_resol);
        for cidx = 1 : N1  % Loop over chirps
            for fidx = 1 : N2  % Loop over frequencies
                 k = omega2(cidx, fidx); m = lambda2(cidx, fidx);
                 if abs(tf0(cidx, fidx)) > Threshold  % Filter based on the threshold
                    if (k < MM) && (k >= 1) ...
                       && (m >= 1) && (m <= MMc)
                       tfrsq2(m,k,tidx) =tfrsq2(m,k,tidx)   + tf0(cidx, fidx);
                    end
                 end
             end
        end
    end
   fprintf('\n');  % New line after the progress is completed 
  