function [ccur,ecur,acur] = Recon_3D(Tx,n,fa,ca,ng,e)

%   Extracts the 3D ridge curve by maximising some local energy and signal reconstruction. 
%   The algorithm uses several random initializations and then
%   forward/backward search.
%
% INPUTS:   
%   Tx : 3D space, e.g. Tx(chirp-rate, frequency, time)
%    n : Number of ridges
%   fa : Maximum allowable frequency variation
%   ca : Maximum allowable chirp-rate variation
%   ng : Number of segments
%    e : threshold, default 10e-8

% OUTPUTS:  
%   ccur : Instantaneous frequency
%   ecur : Instantaneous chirp-rate
%   acur : Instantaneous  coefficients

%Written by Ran Zhang at China Agricultural University on Apr 5th,2022
%ran@cau.edu.cn or thetitleis@hotmail.com

Et=abs(Tx);
%Et=abs(gpuArray(Tx));
[nc,na,N]=size(Tx);
ccur = zeros(n,N);%instantaneous frequency
ecur = zeros(n,N);%instantaneous chirp-rate
acur=zeros(n,N);%instantaneous amp

if nargin ==4
    ng=40;
    e=10e-8;
end
if nargin==5
e =10e-8;%threshold
end

%The algorithm
for r=1:n%nth-ridge
for k = floor(linspace(N/(ng+1),N-2*N/(ng+1),ng)); %Segmentation
    M=max(max(max(Et(:,:,k:k+round(N/ng)-1)))); %Searching starting point based on local maximum. Compatible with
    %versions lower than 2018b.
    %M=max(Et(:,:,k:k+round(N/ng)-1),[],'all');%Compatible with
    %versions later than 2018b(including 2018b)
    [idc idx idy]=ind2sub([nc na length(k:k+round(N/ng)-1)],find(Et(:,:,k:k+round(N/ng)-1)==M));%idx=freq,idc=chirp, idy=time,
    idy=idy+k-1;
    ccur(r,idy) = idx;
    ecur(r,idy)=idc;
    
    % forward search
    for b=idy+1:N
          a=max(1,idx-fa):min(na,idx+fa);
          c=max(1,idc-ca):min(nc,idc+ca);
           %A=Et(c,a,b);
           [M I]=max(Et(c,a,b),[],[1 2],'linear');
           if M>e
               [idcs idxs]=ind2sub([length(c) length(a)],I);
                idx = max(1,idx-fa)+idxs-1;
                idc = max(1,idc-ca)+idcs-1;
                ccur(r,b)=idx;
                ecur(r,b)=idc;
           else
               ccur(r,b)=ccur(r,b-1);
               ecur(r,b)=ecur(r,b-1);
           end
    end

    % backward search
    idx = ccur(r,idy);
    idc=ecur(r,idy);
    for b=idy-1:-1:1
          a=max(1,idx-fa):min(na,idx+fa);
          c=max(1,idc-ca):min(nc,idc+ca);
           %A=Et(c,a,b);
            [M I]=max(Et(c,a,b),[],[1 2],'linear');
            if M>e
                [idcs idxs]=ind2sub([length(c) length(a)],I);
                idx = max(1,idx-fa)+idxs-1;
                idc = max(1,idc-ca)+idcs-1;
                ccur(r,b)=idx;
                ecur(r,b)=idc;
            else
                 ccur(r,b)=ccur(r,b+1);
               ecur(r,b)=ecur(r,b+1);
            end
    end
end
%Reconstructe the mode & Remove the curve
for b=1:N
ci=ecur(r,b);
fi=ccur(r,b);
acur(r,b)=Tx(ci,fi,b);
Et(max(1,ci-ca):min(nc,ci+ca),max(1,fi-fa):min(na,fi+fa),b)=0;
%Et(max(1,imag(ccur(r,i))-ca):min(nc,imag(ccur(r,i))+ca),max(1,real(ccur(r,i)-fa)):min(na,real(ccur(r,i)+fa)),i)=0;
end
end
acur=sum(acur)';%modes summation
ccur=ccur';
ecur=ecur';

