%% 3d plot of squeeze chirplet transform with g_0

figure
QN = 5 ;
D=tfrsq1(:,:,t_idx);
thresh = quantile(abs(D(:)),0.999995);
D(abs(D) < thresh * (10-QN+1)/10) = thresh * (10-QN)/10 ;
for jj = 1: QN
    idx = find(abs(D) <= thresh * (10-jj+1)/10 & abs(D) > thresh * (10-jj)/10 );
    [I1,I2,I3] = ind2sub(size(D),idx);
    scatter3((I3 ) / Hz, newtfrtic(I2) , newtcrtic(I1) , 10, [1 1 1]*(jj-1)/8,  'filled');   
    hold on
end
shading interp;
view(-12,10);
xlabel('Time (s)', 'Rotation', -48,'FontSize',20);
ylabel('Frequency (Hz)', 'Rotation', 3,'FontSize',20);
zlabel('Chirprate (Hz/s)', 'FontSize',20);
colormap(1-gray)
colorbar
set(gca,'FontSize',20)
title('3D Plot of SWLCT'); 