function   [Tf_sc]=Xray_transform(tfc,tfrtic,tcrtic,sigma,t, t0)

% Inputs:
%   x - Input signal (column vector)
%   tfc - Initial time-frequency chirparate representation (3D matrix)
%   tfrtic -  frequency bins
%   tcrtic -  chirp rate bins
%   t - Time bins

%   Tf_sc - X-ray time-frequency chirprate representation (3D matrix)



tic 
del_t = t(2) - t(1);del_f=tfrtic(2)-tfrtic(1);
[N1, N2, N3] = size(tfc); %%cidx_fidx_tidx;
Tf_sc = zeros(N1, N2, N3); 

tfc_abs=abs(tfc);

s=2;

time=(-64:1:64)*t0;


tlen=length(time);

lent=round((tlen+1)/2);


g = exp(-time.^2./(2*sigma^2))./(sigma*sqrt(2*pi));



for i=1:N1
    for j=1:N2
       for k=1:tlen        
              pp = round((tfrtic(j)+tcrtic(i)*time(k))/del_f);          
              if pp>0&&pp<=N2                   
                   for n=1:N3
                       qq=n+round(t0*(k-lent)/del_t);
                       if 1<=qq&&qq<=N3
                       Tf_sc(i, j, n) = Tf_sc(i, j, n) +g(k)*tfc_abs(i,pp ,qq );
                       end
                   end
               end
        end
    end
end



Tf_sc=Tf_sc.*t0;
 

toc



