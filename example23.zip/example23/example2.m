clear ; 
Hz =128; % sampling rate
L = 4 ; % time duration in second
deltat=1/Hz;
t = (1/Hz:1/Hz:L)' ;
x1 =exp(2*pi*1i*(4*t.^2+20*t)); % second component
der_x1=8*t+20;
dder_x1=8*ones(length(t),1);
x2 = exp(2*pi*1i*(6*t.^2+12*t)); % second component
der_x2=12*t+12;
dder_x2=12*ones(length(t),1);




figure
pdph1=plot(t,der_x1,'r-','linewidth',2);
hold on
pdph2=plot(t,der_x2,'b-','linewidth',2);
legend([pdph1, pdph2], 'IF of y_1(t)', 'IF of y_2(t)', 'Location', 'northwest'); 
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 



figure
pddph1=plot(t,dder_x1,'r-','linewidth',2);
hold on
pddph2=plot(t,dder_x2,'b-','linewidth',2);
legend([pddph1, pddph2], 'Chirprate of y_1(t)', 'Chirpratre of y_2(t)', 'Location', 'northwest'); 
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([t(1) 4 6 15]);


x = x1 + x2;

alpha1 = 0.018;alpha5 = 0.017;alpha2 =2.5;alpha6 =80;


alpha=[alpha1,alpha2, 0,0,alpha5,alpha6];

%alpha1==0.017-0.018;
%alpha5=0.017;
%alpha2=2.4-2.5;
%alpha4=79.5-85.5;


delta_a=1/128;
chrrange=20;
a0=2^(round(0.6*length(t))*delta_a)/Hz;
%% please chose one modes to run
p=6;

%p - Type of SWLCT 
profile on -memory; %profile off; 

if p==1
[tfc1, lambda1,omega1,tfrtic, tcrtic] = SWLCT1_dyadic23(x, Hz, alpha1,delta_a,a0);

elseif p==5
[tfc1, lambda1,omega1,tfrtic, tcrtic]  = SWLCT5_dyadic23(x, Hz, alpha5,delta_a,a0);

elseif p==2
[tfc1, lambda1,omega1,tfrtic, tcrtic] = SWLCT2_23(x, Hz, alpha2,chrrange);

elseif p==6
[tfc1, lambda1,omega1,tfrtic, tcrtic]=SWLCT6_23(x, Hz, alpha6,chrrange);

else
    error('Invalid value of p');
end


profile viewer;  

%p=1, 36.49s   0.50G
%p=5, 37.62s   0.50G
%p=2, 32.98s   0.50G
%p=6 36.58s
%% X-ray transform
[tf_sc]=Xray_transform(tfc1,tfrtic,tcrtic,1,t,2/Hz);


%% Please choose synchrosqueezed with WLCT or XWLCT
 q=2; % or 2


freq_resol=1/12;chr_resol=1/32; %Reset resolution

if q==1 %(SWLCT) synchrosqueezed  WLCT
[tfrsq1,newtfrtic,newtcrtic] = Msqueeze2(x, tfc1, lambda1, omega1,chrrange,freq_resol,chr_resol, deltat);
elseif q==2  %(SXWLCT)  synchrosqueezed X-ray WLCT
[tfrsq1,newtfrtic,newtcrtic] = Msqueeze2(x, tf_sc, lambda1, omega1,chrrange,freq_resol,chr_resol, deltat);
end

%% the ridges exctors
if p == 1 || p == 5
[NIFs,NCRs]=ridge_3D(tfrsq1,2,10,10,0.00001,0.00001,10); % 3D ridges exctors
elseif p==2 || p==6
[NIFs,NCRs]=ridge_3D(tfrsq1,2,15,15,0.00001,0.00001,15); % 3D ridges exctors    
end




 for i=1:length(NIFs)
       % if1 = smooth(medfilt1(newtfrtic(NIFs(:,1))));
       % if2 = smooth(medfilt1(newtfrtic(NIFs(:,2))));
       % chirp1=smooth(medfilt1(newtcrtic(NCRs(:,1))));
       % chirp2=smooth(medfilt1(newtcrtic(NCRs(:,2))));

      
       if1 =newtfrtic(NIFs(:,1))';
       if2 =newtfrtic(NIFs(:,2))';
       chirp1=newtcrtic(NCRs(:,1))';
       chirp2=newtcrtic(NCRs(:,2))';
 end


%%  plot  estimated  ridges

figure;
h1 = plot(t, if1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated IFs'); 
hold on;
plot(t, if2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); 
h2 = plot(t, der_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, der_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); 
legend([h1, h2], 'FontName', 'Times New Roman', 'FontSize', 20,'Location', 'northwest');
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency(Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([10 66]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);


figure;
h3 = plot(t, chirp1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated CRs'); 
hold on;
plot(t, chirp2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
h4 = plot(t, dder_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, dder_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
legend([h3, h4], 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Chirprate (Hz/s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([7 14]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);








%% the attenuation of chirprate at the point of intersection

if p == 1 || p == 5

figure;
sq1 = squeeze(abs(tfc1(:,145,256))); 
hold on
plot(1./tcrtic, abs(sq1)./max(abs(sq1)),'LineWidth', 2); 
ax = gca;
xmin = min(1./tcrtic);
xmax = max(1./tcrtic);
xticks = 2.^(floor(log2(xmin)):ceil(log2(xmax)));
set(ax, 'XScale', 'log', 'XTick', xticks);
xlabel('1/Chirprate', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(1./tcrtic(130), sq1(130)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(1./tcrtic(205), sq1(205)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =-0.001; 
vertical_offset1 = 0; 
text(1./tcrtic(130) + horizontal_offset1, sq1(130)./max(abs(sq1)) - vertical_offset1, sprintf('\\lambda = %.3f', 0.083), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =-0.02; 
vertical_offset2 = -0.07; 
text(1./tcrtic(205) + horizontal_offset2, sq1(205)./max(abs(sq1)) - vertical_offset2, sprintf('\\lambda = %.3f', 0.125), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0.5, 1.1])







figure;
sq2 = squeeze(tf_sc(:,145,256)); 
hold on
plot(1./tcrtic, abs(sq2)./max(abs(sq2)),'LineWidth', 2); 
ax = gca;
xmin = min(1./tcrtic);
xmax = max(1./tcrtic);ylim([0.5, 1.1])
xticks = 2.^(floor(log2(xmin)):ceil(log2(xmax)));
set(ax, 'XScale', 'log', 'XTick', xticks);
xlabel('1/Chirprate', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(1./tcrtic(130), sq2(130)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(1./tcrtic(205), sq2(205)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =0.001; 
vertical_offset1 = -0.02; 
text(1./tcrtic(130) + horizontal_offset1, sq2(130)./max(abs(sq2)) - vertical_offset1, sprintf('\\lambda = %.3f', 0.083), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =-0.02; 
vertical_offset2 = -0.1; 
text(1./tcrtic(205) + horizontal_offset2, sq2(205)./max(abs(sq2)) - vertical_offset2, sprintf('\\lambda = %.3f', 0.125), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0.2, 1.1])



% figure;
% BB=abs(squeeze(tfc1(:,:,2*Hz)));
% surf(tfrtic, 1./tcrtic, BB);
% shading interp;
% ax = gca;
% ymin = min(1./tcrtic(:));
% ymax = max(1./tcrtic(:));
% yticks = 2.^(floor(log2(ymin)):ceil(log2(ymax)));
% yticks = yticks(yticks >= ymin & yticks <= ymax);
% set(ax, 'YScale', 'log', 'YTick', yticks);
% xlabel('Frequency (Hz)', 'Rotation', 20,'FontSize',20)
% ylabel('-1/Chirprate ', 'Rotation', -30,'FontSize',20)
% zlabel('Magnitude', 'FontSize', 20, 'FontWeight', 'bold');
% axis tight;
% 
% 
% figure;
% BB=abs(squeeze(tf_sc(:,:,4*Hz)));
% surf(tfrtic, 1./tcrtic, BB);
% shading interp;
% ax = gca;
% ymin = min(1./tcrtic(:));
% ymax = max(1./tcrtic(:));
% yticks = 2.^(floor(log2(ymin)):ceil(log2(ymax)));
% yticks = yticks(yticks >= ymin & yticks <= ymax);
% set(ax, 'YScale', 'log', 'YTick', yticks);
% xlabel('Frequency (Hz)', 'Rotation', 20,'FontSize',20)
% ylabel('-1/Chirprate ', 'Rotation', -30,'FontSize',20)
% zlabel('Magnitude', 'FontSize', 20, 'FontWeight', 'bold');
% axis tight;



elseif p == 2 

figure;
sq1 = squeeze(abs(tfc1(:,145,256))); 
normalized_sq = abs(sq1)/max(abs(sq1)); 
plot(-tcrtic, normalized_sq, 'LineWidth', 2); 
xlabel('Chirprate', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
xlim([-20 0]); 
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(-tcrtic(147), sq1(147)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(-tcrtic(110), sq1(110)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =-4; 
vertical_offset1 = -1.99; 
text(-tcrtic(147) + horizontal_offset1, -sq1(147)./max(abs(sq1)) - vertical_offset1, sprintf('\\lambda = %.3f', -11.45), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =4.5; 
vertical_offset2 = -2.05; 
text(-tcrtic(110) + horizontal_offset2, -sq1(110)./max(abs(sq1)) - vertical_offset2, sprintf('\\lambda = %.3f', -8.55), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0.5, 1.1])
hold off;


figure;
sq2 = squeeze(abs(tf_sc(:,145,256))); 
normalized_sq = abs(sq2)/max(abs(sq2)); 
plot(-tcrtic, normalized_sq, 'LineWidth', 2); 
xlabel('-Chirprate', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
xlim([-20 0]); 
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(-tcrtic(154), sq2(154)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(-tcrtic(103), sq2(103)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =-4; 
vertical_offset1 = -1.99; 
text(-tcrtic(154) + horizontal_offset1, -sq2(154)./max(abs(sq2)) - vertical_offset1, sprintf('\\lambda = %.2f', -12), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =05; 
vertical_offset2 = -2; 
text(-tcrtic(103) + horizontal_offset2, -sq2(103)./max(abs(sq2)) - vertical_offset2, sprintf('\\lambda = %.2f', -8), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0.2, 1.1])
hold off;




elseif p == 6 

figure;
sq1 = squeeze(abs(tfc1(:,145,256))); 
normalized_sq = abs(sq1)/max(abs(sq1)); 
plot(-tcrtic, normalized_sq, 'LineWidth', 2); 
xlabel('-Chirprate', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
xlim([-20 0]); 
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(-tcrtic(155), sq1(155)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(-tcrtic(102), sq1(102)./max(abs(sq1)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =-4; 
vertical_offset1 = -1.99; 
text(-tcrtic(155) + horizontal_offset1, -sq1(155)./max(abs(sq1)) - vertical_offset1, sprintf('\\lambda = %.3f', -12.07), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =4.5; 
vertical_offset2 = -2.05; 
text(-tcrtic(102) + horizontal_offset2, -sq1(102)./max(abs(sq1)) - vertical_offset2, sprintf('\\lambda = %.3f', -7.92), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0, 1.1])
hold off;


figure;
sq2 = squeeze(abs(tf_sc(:,145,256))); 
normalized_sq = abs(sq2)/max(abs(sq2)); 
plot(-tcrtic, normalized_sq, 'LineWidth', 2); 
xlabel('-Chirprate ', 'FontSize', 20);
ylabel('Normalized Amplitude', 'FontSize', 20);
xlim([-20 0]); 
axis xy; 
set(gca, 'FontSize', 20);
hold on
plot(-tcrtic(154), sq2(154)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
plot(-tcrtic(103), sq2(103)./max(abs(sq2)), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
horizontal_offset1 =-4; 
vertical_offset1 = -1.9; 
text(-tcrtic(154) + horizontal_offset1, -sq2(154)./max(abs(sq2)) - vertical_offset1, sprintf('\\lambda = %.2f', -12), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom');
horizontal_offset2 =05; 
vertical_offset2 = -1.9; 
text(-tcrtic(103) + horizontal_offset2, -sq2(103)./max(abs(sq2)) - vertical_offset2, sprintf('\\lambda = %.2f', -8), ...
    'FontSize', 16, 'Color', 'k', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
ylim([0.2, 1.1])
hold off;





% figure;
% AA=abs(squeeze(tfc1(:,:,256)));
% surf(tfrtic, -tcrtic, AA);
% shading interp;
% view(-30, 30);
% xlabel('Frequency (Hz)', 'Rotation', 20,'FontSize',20)
% ylabel('-Chirprate ', 'Rotation', -30,'FontSize',20)
% zlabel('Magnitude', 'FontSize', 20);
% axis tight;ylim([-20,0]);
% set(gca,'FontSize',20)


% figure;
% AA=abs(squeeze(tf_sc(:,:,2*Hz)));
% surf(tfrtic, -tcrtic, AA);
% shading interp;
% view(-30, 30);
% xlabel('Frequency (Hz)', 'Rotation', 20,'FontSize',20)
% ylabel('-Chirprate ', 'Rotation', -30,'FontSize',20)
% zlabel('Magnitude', 'FontSize', 20, 'FontWeight', 'bold');
% axis tight;ylim([-20,0]);
% set(gca,'FontSize',20)

end

%% time-frequency projection

tfproj1 = zeros(size(tfrsq1,2),size(tfrsq1,3));
for i = 1:size(tfproj1,1)
    for j = 1:size(tfproj1,2)
        tfproj1(i,j) = sum(abs((tfrsq1(:,i,j)).^(1)));
    end
end
figure
imageSQ(t, newtfrtic, tfproj1) 
shading interp;
axis xy; 
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency (Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
title('Time-Frequency projection');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);






%% recov signal 
t_idx = 1:length(t);
t_show = t(t_idx);



IFs=zeros(size(NIFs));CRs=zeros(size(NCRs));

for j=1:length(t)
    diff1=abs(tfrtic-if1(j)); diff2=abs(tfrtic-if2(j));       
    [minValue1, minIndex1] = min(diff1); [minValue2, minIndex2] = min(diff2);
    IFs(j,1)=minIndex1; IFs(j,2)=minIndex2;
    diff3=abs(tcrtic-chirp1(j)); diff4=abs(tcrtic-chirp2(j));     
    [minValue3, minIndex3] = min(diff3); [minValue4, minIndex4] = min(diff4);
    CRs(j,1)=minIndex3; CRs(j,2)=minIndex4;

end




%% mode retrieval
[recov,cn] = recov_SSO_group(if1, if2, chirp1, chirp2, IFs,CRs, tfc1,alpha, p);


load('Condnum_data.mat');    %the storage of the condition number
Condnum(:,p,q)=cn;
save('Condnum_data.mat', 'Condnum');
%plot(t,Condnum(:,1,2))

if sum(abs(real(x1-recov(:,1))))<sum(abs(real(x2-recov(:,1))))
figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);


subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

else

figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);

%title('error of x1 between real-signal and ridge-IF-CR reconstruction signal');
subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

end
[MSEIFx1, MSEIFx2, MSECRx1, MSECRx2] = MSE_ridge(if1, if2, chirp1, chirp2, der_x1, dder_x1, der_x2, dder_x2);
disp([MSEIFx1, MSEIFx2, MSECRx1, MSECRx2])
[errorx1,errorx2] = MSE_recov(x1,x2,recov);
disp([errorx1,errorx2])
% SWLCT
%p=1  0.0838    0.0521    0.4102    0.2561   0.1438    0.0945
%p=2  0.1049    0.1046    0.6112    0.6372    0.4124    0.4144
%p=5  0.0762    0.0666    0.3192    0.2570    0.1171    0.0794
%p=6  0.0512    0.1046    0.3768    0.6421    0.1954    0.1901

% SXWLCT
% p=1   0.1078    0.0782    0.2724    0.3092    0.0828    0.0474
% p=2   0.0598    0.0506    0.3076    0.2814    0.0437    0.0429
% p=5   0.1052    0.0790    0.2619    0.2977    0.0812    0.0473
% p=6   0.0548    0.0537    0.3508    0.2681    0.0985    0.0559


