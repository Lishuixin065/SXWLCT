clear ; 
Hz = 128; % sampling rate
L = 8 ; % time duration in second
deltat=1/Hz;
t = (1/Hz:1/Hz:L)' ;
x1 =exp(2*pi*1i*(2*t.^2+18*t)); % second component
der_x1=4*t+18;
dder_x1=4*ones(length(t),1);
x2 = exp(2*pi*1i*(2*t.^2+18*t+64/pi*cos(pi*t./8+pi/2))); % second component
der_x2=4*t-8*sin(pi*t./8+pi/2)+18;
dder_x2=4-1*pi*cos(pi*t./8+pi/2);


figure
pltder1 = plot(t, der_x1, 'r', 'linewidth', 1.5);
hold on
pltder2 = plot(t, der_x2, 'b-', 'linewidth', 1.5);
 legend([pltder1, pltder2], 'IF of z_1(t)', 'IF of z_2(t)', 'Location', 'northwest'); 
  set(legend, 'FontName', 'Times New Roman');
xlabel('Time (s)', 'FontSize', 20);
ylabel('Frequency (Hz)', 'FontSize', 20);
set(gca, 'FontSize', 20);
axis xy;
axis([t(1) 8 10 64]);


figure
pltder1 = plot(t, dder_x1, 'r', 'linewidth', 1.5);
hold on
pltder2 = plot(t, dder_x2, 'b-', 'linewidth', 1.5);
legend([pltder1, pltder2], 'Chirprate of z_1(t)', 'Chirprate of z_2(t)', 'Location', 'northwest'); 
set(legend, 'FontName', 'Times New Roman');
xlabel('Time (s)', 'FontSize', 20);
ylabel('chirprate (Hz)', 'FontSize', 20);
set(gca, 'FontSize', 20);
axis xy;
axis([t(1) 8 3 9]);









x = x1 + x2;

alpha1 = 0.062;alpha5 = 0.06;alpha2 = 1;alpha6 =29;
alpha=[alpha1,alpha2, 0,0,alpha5,alpha6];
%alpha1=0.062-0.064;
%alpha5=0.06-0.062;
%alpha2=3.7-3.9;
%alpha6=gs=28-29.5 ;


delta_a=1/128;
start=round(0.25*length(t));%(J)
a0=2^(round(0.25*length(t))*delta_a)/Hz;
chrrange=12;


%% please chose one modes to run
p=5;

%p - Type of SWLCT 
profile on -memory;  profile off;
if p==1
[tfc1, lambda1,omega1,tfrtic, tcrtic] = SWLCT1_dyadic23(x, Hz, alpha1,delta_a,a0);

elseif p==5
[tfc1, lambda1,omega1,tfrtic, tcrtic]  = SWLCT5_dyadic23(x, Hz, alpha5,delta_a,a0);

elseif p==2
[tfc1, lambda1,omega1,tfrtic, tcrtic] = SWLCT2_23(x, Hz, alpha2,chrrange);

elseif p==6
[tfc1, lambda1,omega1,tfrtic, tcrtic]=SWLCT6_23(x, Hz, alpha6,chrrange);

else
    error('Invalid value of p');
end

profile viewer;  
%P=1 210.88s  4.01G
%P=2 199.67s  4.01G
%P=5 203.80s  4.01G
%p=6 216.88s  4.01G


freq_resol=1/16;chr_resol=1/64;

[tf_sc]=Xray_transform(tfc1,tfrtic,tcrtic,1,t,2/Hz);

[tfrsq1,newtfrtic,newtcrtic] = Msqueeze2(x, tf_sc, lambda1, omega1,chrrange,freq_resol,chr_resol, deltat);
% 
if p == 1 || p == 6
[NIFs,NCRs]=ridge_3D(tfrsq1,2,10,10,0.00001,0.00001,5); % 3D ridges exctors
elseif p==2 || p==5
[NIFs,NCRs]=ridge_3D(tfrsq1,2,15,15,0.00001,0.00001,15); % 3D ridges exctors    
end


 for i=1:length(NIFs)
       % if1 = smooth(medfilt1(newtfrtic(NIFs(:,1))));
       % if2 = smooth(medfilt1(newtfrtic(NIFs(:,2))));
       % chirp1=smooth(medfilt1(newtcrtic(NCRs(:,1))));
       % chirp2=smooth(medfilt1(newtcrtic(NCRs(:,2))));
   
       if1 =smooth(newtfrtic(NIFs(:,1)));
       if2 =smooth(newtfrtic(NIFs(:,2)));
       chirp1=smooth(newtcrtic(NCRs(:,1)));
       chirp2=smooth(newtcrtic(NCRs(:,2)));
       
 end





%%  plot  estimated  ridges

figure;
h1 = plot(t, if1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated IFs'); 
hold on;
plot(t, if2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); 
h2 = plot(t, der_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, der_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); 
legend([h1, h2], 'FontName', 'Times New Roman', 'FontSize', 20,'Location', 'northwest');
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency(Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([10 64]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);


figure;
h3 = plot(t, chirp1, 'r:', 'LineWidth', 2, 'DisplayName', 'Estimated CRs'); 
hold on;
plot(t, chirp2, 'r:', 'LineWidth', 2, 'HandleVisibility', 'off'); % 不显示在图例中
h4 = plot(t, dder_x1, 'b-', 'LineWidth', 1, 'DisplayName', 'Ground truth'); 
plot(t, dder_x2, 'b-', 'LineWidth', 1, 'HandleVisibility', 'off'); % 不显示在图例中
legend([h3, h4], 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Chirprate (Hz/s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylim([3 9]);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);





%% time-frequency projection

tfproj1 = zeros(size(tfrsq1,2),size(tfrsq1,3));
for i = 1:size(tfproj1,1)
    for j = 1:size(tfproj1,2)
        tfproj1(i,j) = sum(abs((tfrsq1(:,i,j)).^(1)));
    end
end
figure
imageSQ(t, newtfrtic, tfproj1) 
shading interp;
axis xy; 
xlabel('Time (s)', 'FontSize', 20, 'FontName', 'Times New Roman');
ylabel('Frequency (Hz)', 'FontSize', 20, 'FontName', 'Times New Roman');
title('Time-Frequency projection');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);






%% recov signal 
t_idx = 1:length(t);
t_show = t(t_idx);



IFs=zeros(size(NIFs));CRs=zeros(size(NCRs));

for j=1:length(t)
    diff1=abs(tfrtic-if1(j)); diff2=abs(tfrtic-if2(j));       
    [minValue1, minIndex1] = min(diff1); [minValue2, minIndex2] = min(diff2);
    IFs(j,1)=minIndex1; IFs(j,2)=minIndex2;
    diff3=abs(tcrtic-chirp1(j)); diff4=abs(tcrtic-chirp2(j));     
    [minValue3, minIndex3] = min(diff3); [minValue4, minIndex4] = min(diff4);
    CRs(j,1)=minIndex3; CRs(j,2)=minIndex4;

end




%% mode retrieval
[recov,cn] = recov_SSO_group(if1, if2, chirp1, chirp2, IFs,CRs, tfc1,alpha, p);

%plot(t,cn)

if sum(abs(real(x1-recov(:,1))))<sum(abs(real(x2-recov(:,1))))
figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);


subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

else

figure
subplot(2, 1, 1);
plot(t_show, real(x1(t_idx))-real(recov(t_idx,2)), 'k');
ylim([-1.5 1.5]);
legend('$error_1$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);

%title('error of x1 between real-signal and ridge-IF-CR reconstruction signal');
subplot(2, 1, 2);
plot(t_show, real(x2(t_idx))-real(recov(t_idx,1)), 'k');
ylim([-1.5 1.5]);
legend('$error_2$', 'FontSize', 20, 'Interpreter', 'latex');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 20);
xlabel('Time (s)','FontSize',20);
%title('error of x2 between real-signal and ridge-IF-CR reconstruction signal');

end
[MSEIFx1, MSEIFx2, MSECRx1, MSECRx2] = MSE_ridge(if1, if2, chirp1, chirp2, der_x1, dder_x1, der_x2, dder_x2);
disp([MSEIFx1, MSEIFx2, MSECRx1, MSECRx2])
[errorx1,errorx2] = MSE_recov(x1,x2,recov);
disp([errorx1,errorx2])

%P=1 0.0221    0.0286         0    0.0493  0.0250    0.0222
%p=2 0.0221    0.0247    0.0280    0.0555  0.0197    0.0201
%p=5 0.0221    0.0284    0.0005    0.0500 0.0240    0.0216
%p=6 0.0223    0.0380    0.0374    0.1094   0.0387    0.0355
