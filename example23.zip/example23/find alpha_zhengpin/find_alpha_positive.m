%%%%%%%%%%%%%%%%%%% Example2 %%%%%%%%%%%%%%
% clear ; 
% Hz =128; % sampling rate
% L = 4 ; % time duration in second
% deltat=1/Hz;
% t = (1/Hz:1/Hz:L)' ;
% x1 =exp(2*pi*1i*(4*t.^2+20*t)); % second component
% der_x1=8*t+20;
% dder_x1=8*ones(length(t),1);
% x2 = exp(2*pi*1i*(6*t.^2+12*t)); % second component
% der_x2=12*t+12;
% dder_x2=12*ones(length(t),1);
% delta_a=1/128;start=round(0.6*length(t));chrrange=20;
% x = x1 + x2; % input signal
% l=2.5;


%%%%%%%%%%%%%%%%%%% Example3 %%%%%%%%%%%%%%
clear ; 
Hz = 128; % sampling rate
L = 8 ; % time duration in second
deltat=1/Hz;
t = (1/Hz:1/Hz:L)' ;
x1 =exp(2*pi*1i*(2*t.^2+18*t)); % second component
der_x1=4*t+18;
dder_x1=4*ones(length(t),1);
x2 = exp(2*pi*1i*(2*t.^2+18*t+64/pi*cos(pi*t./8+pi/2))); % second component
der_x2=4*t-8*sin(pi*t./8+pi/2)+18;
dder_x2=4-1*pi*cos(pi*t./8+pi/2);
delta_a=1/128;chrrange=12;a0=2^(round(0.25*length(t))*delta_a)/Hz;
x = x1 + x2; 
l=2.5;



%% WLCT1
gs_del=0.001;
gs=0.002:gs_del:0.060; 
[opt_gs1,entro1]=find_sigma_WLCT1_dyadic_positive(x,Hz,l,delta_a,a0,gs);
%example2 l=2.5  gs=0.017-0.018  gs_del=0.001  entro=14.2429
%example3 l=2.5  gs=0.062-0.064; gs_del=0.001  entro=16.5463

%% WLCT5
gs_del=0.001;
gs=0.008:gs_del:0.064; 
[opt_gs2,entro2]=find_sigma_WLCT5_dyadic_positive(x,Hz,l,delta_a,a0,gs);
%example2 l=2.5 gs=0.017       gs_del=0.001  entro=14.2432
%example3 l=2.5 gs=0.060-0.062 gs_del=0.001; entr0=16.5473

%% WLCT2
gs_del=0.1;
gs=0.8:gs_del:1.2; 
[opt_gs3,entro3]=find_sigma_WLCT2_positive(x,Hz,l,chrrange,gs);
%example2  l=2.5, gs=2.4-2.5,  gs_del=0.1;      entro=14.3954
%example3  l=2.5,  gs=0.9-1.0  gs_del=0.1;      entro=16.5463
%% WLCT 6
gs_del=0.5;
gs=27.5:gs_del:100;
[opt_gs4,entro4]=find_sigma_WLCT6_positive(x,Hz,l,chrrange,gs);
%example2  l=2.5, gs=79.5-85.5,  entro=14.3425
%example3  l=2.5  gs=28-29.5    gs_del=0.5;

