
function [opt_gs1,entro1]=find_sigma_WLCT2_positive(x,Hz,l,chrrange,gs)

leng=length(gs); 
entro1=zeros(1,leng); 
for j=1:leng

[tfc,tfrtic,tcrtic] =WLCT2_positive(x, Hz, gs(j),chrrange);

upp1=sum(sum(sum(abs(tfc).^(2*l))));
dow1=sum(sum(sum(abs(tfc).^2)))^(l);
entro1(j)=1/(1-l)*log(upp1/dow1);
%disp("j"), 
results = [j, gs(j), entro1(j)];
disp(results);
end 

[gs_min1, min_ind1]=min(entro1);


opt_gs1=gs(min_ind1);
disp(opt_gs1);
