
function [IFs,CRs] = ridge_3D(Tx,n,fa,ca,k1,k2,ng,e)
% Inputs:
%   Tx - 3D time-frequency representation (nc x na x N matrix)
%   n - Number of ridges to extract
%   fa - Frequency analysis range
%   ca - Chirp rate analysis range
%   k1 - Weight for chirp rate difference
%   k2 - Weight for frequency difference
%   ng - Number of segments for ridge extraction (default: 40)
%   e - Threshold for ridge extraction (default: 1e-8)
%
% Outputs:
%   IFs - Extracted instantaneous frequencies (n x N matrix)
%   CRs - Extracted chirp rates (n x N matrix)





Et =(abs(Tx)+eps).^2;

[nc,na,N]=size(Tx);
IFs = zeros(n,N);%instantaneous frequency
CRs = zeros(n,N);%instantaneous chirp-rate

if nargin ==6
    ng=40;
    e=10e-8;
end
if nargin==7
e =10e-8;%threshold
end



for r=1:n
for k = floor(linspace(N/(ng+1),N-2*N/(ng+1),ng)) %Segmentation
    M=max(max(max(Et(:,:,k:k+round(N/ng)-1)))); 
    [idc, idf, idt]=ind2sub([nc na length(k:k+round(N/ng)-1)],find(Et(:,:,k:k+round(N/ng)-1)==M));%idf=freq,idc=chirp, idt=time,
    idt=idt+k-1;
    IFs(r,idt) = idf;
    CRs(r,idt)=idc;

    % forward search
    for b=idt+1:N
          a=max(1,idf-fa):min(na,idf+fa);
          c=max(1,idc-ca):min(nc,idc+ca);
          delta_c = (c-1*CRs(b-1)).^2;
          delta_a = (a-1*IFs(b-1)).^2;   
    D = k1 * delta_c' * ones(1, length(a)) + k2 * ones(length(c), 1) * delta_a;
    E = Et(c, a, b) - D;
    
    [M, I] = max(E, [], [1 2],'linear');
    
           if M>e
               [idcs, idfs]=ind2sub([length(c) length(a)],I);               
                idf = max(1,idf-fa)+idfs-1;
                idc = max(1,idc-ca)+idcs-1;
                IFs(r,b)=idf;
                CRs(r,b)=idc;
           else
               IFs(r,b)=IFs(r,b-1);
               CRs(r,b)=CRs(r,b-1);
           end
    end

    % backward search
    idf = IFs(r,idt);
    idc=CRs(r,idt);
    for b=idt-1:-1:1
          a=max(1,idf-fa):min(na,idf+fa);
          c=max(1,idc-ca):min(nc,idc+ca);
          delta_c = (c-1*CRs(b+1)).^2;
          delta_a = (a-1*IFs(b+1)).^2;
         D = k1 * delta_c' * ones(1, length(a)) + k2 * ones(length(c), 1) * delta_a;      
         E = Et(c, a, b) - D;
        [M, I] = max(E, [], [1 2],'linear');
    
         
            if M>e
                [idcs ,idfs]=ind2sub([length(c) length(a)],I);
                idf = max(1,idf-fa)+idfs-1;
                idc = max(1,idc-ca)+idcs-1;
                IFs(r,b)=idf;
                CRs(r,b)=idc;
            else
                 IFs(r,b)=IFs(r,b+1);
               CRs(r,b)=CRs(r,b+1);
            end
    end
end

%Reconstructe the mode & Remove the curve
for b=1:N
ci=CRs(r,b);
fi=IFs(r,b);

Et(max(1,ci-ca):min(nc,ci+ca),max(1,fi-fa):min(na,fi+fa),b)=0;

end
end

IFs=IFs';
CRs=CRs';
end
